
const socket = io();
function send(){
    const val = document.getElementById("m").value;
    socket.emit('chat message', val);
    document.getElementById("m").value = "";
}
socket.on('chat message', function(msg){
    const li = document.createElement("li");
    li.textContent = msg;
    document.getElementById("messages").appendChild(li);
});
